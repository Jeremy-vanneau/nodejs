const express = require('express');
const fs = require('fs');
const app = express();

app.get('/', function(req, res) {
  res.sendFile(__dirname + '/index.html');
})

app.get('/video', function(req, res) {
  const movie = 'video.mp4';
  const stat = fs.statSync(movie);
  const fileSize = stat.size;
  const range = req.headers.range;
  console.log(range);

    const head = {
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(200, head);
    fs.createReadStream(movie).pipe(res);
});

app.listen(3000, function() {   
   console.log('Listening on port 3000');
});